package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Room;
import com.cg.hms.dao.IRoomDAO;
import com.cg.hms.dao.RoomDAOImpl;
import com.cg.hms.exception.HMSException;

public class RoomServiceImpl implements IRoomService {
	
private IRoomDAO roomDao;
	
	public RoomServiceImpl() {
		roomDao = new RoomDAOImpl();
	}

	@Override
	public List<Room> listRoom(int hcode,String rtype) throws HMSException {
		return roomDao.listRoom(hcode,rtype);
	}

}
