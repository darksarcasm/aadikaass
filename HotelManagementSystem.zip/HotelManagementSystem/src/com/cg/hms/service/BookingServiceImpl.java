package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.BookingDaoImpl;
import com.cg.hms.dao.IBookingDao;
import com.cg.hms.exception.HMSException;

public class BookingServiceImpl implements IBookingService {

	
private IBookingDao bookingDao;
	
	public BookingServiceImpl() {
		bookingDao = new BookingDaoImpl();
	}

	
	@Override
	public boolean saveBooking(Booking book) throws HMSException {
		return bookingDao.saveBooking(book);
	}


	@Override
	public List<Booking> listBookingDetailsByRoomid(int roomid) throws HMSException {
		return bookingDao.listBookingDetailsByRoomid(roomid);
	}


	@Override
	public Room findAmount(int rcode) throws HMSException {
		// TODO Auto-generated method stub
		return bookingDao.findAmount(rcode);
	}

}
